Morrow District — Unreal Engine 5 level package

This package contains native Unreal assets for the LVL_01_MorrowDistrict blockout.
It was prepared for Unreal Engine 5.8.

To add it to another UE5 project:
1. Close the target project in Unreal Editor.
2. Extract this archive at the target project's root so its Content folder merges into the project's Content folder.
3. Reopen the target .uproject and open /Game/Maps/LVL_01_MorrowDistrict in the Content Browser.

The level uses the engine's BasicShapes cube and cylinder, plus the seven included blockout materials. The archive keeps the native .umap and .uasset files editable. Unreal's generic Import button is for external source formats; for native UE levels, copy the assets with their dependencies or use Content Browser > Asset Actions > Migrate from the source project.
